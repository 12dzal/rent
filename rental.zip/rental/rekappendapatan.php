

<div class="panel-heading">
    <div class="panel-title">
        <i class="glyphicon glyphicon-wrench pull-right"></i>
        <h4>Rekap Pendapatan</h4>
    </div>
</div>
<div class="panel-body">	
    <script>
        $(function() {
            $("#from").datepicker({
                defaultDate: "-1w",
                changeMonth: true,
                numberOfMonths: 1,
                onClose: function(selectedDate) {
                    $("#to").datepicker("option", "minDate", selectedDate);
                }
            });
            $("#to").datepicker({
                defaultDate: "+1w",
                changeMonth: true,
                numberOfMonths: 2,
                onClose: function(selectedDate) {
                    $("#from").datepicker("option", "maxDate", selectedDate);
                }
            });
        });
    </script>
    <form method="post" action="?page=rekappendapatan">
        <div class="control-group">

            <label for="from">From</label>
            <input type="text" id="from" name="from"/>
            <label for="to">to</label>
            <input type="text" id="to" name="to"/>
        </div>
        <div class="control-group">
            <label></label>
            <div class="controls">
                <button type="submit" class="btn btn-primary" value ='Cari' name='caribtn' id='caribtn'>
                    Cari
                </button>
            </div>
        </div>
    </form>
    <hr>
    <?php
    require_once 'koneksi.php';
    require_once 'fungsi.php';


    if (isset($_POST['caribtn'])) {
        $tgldari = $_POST['from'];
        $tglsampai = $_POST['to'];

        

        $sqx = "select count(*) as no from kembali where tanggal_kembali between '$tgldari' and '$tglsampai'";
        $qx = mysql_query($sqx);
        while ($n = mysql_fetch_array($qx)) {
            $no = $n['no'];
            echo "Terdapat Total " . $no . " transaksi";
            echo "<hr>";
        }
        echo "Daftar Rekap Pendapatan dari tanggal " . tglindo($tgldari) . " sampai :" . tglindo($tglsampai) . "<br>";
        $sx = "select * from kembali where tanggal_kembali between '$tgldari' and '$tglsampai'";
        $q = mysql_query($sx);
        $nomor = 0;
        $jumtot=0;
        echo "<table class=\"table table-striped\"><tr><th>No</th><th>Tanggal</th><th>Uraian</th><th style='text-align:right;'>Jumlah</th></tr>";
        while ($n = mysql_fetch_array($q)) {
            $nomor ++;
            $tgl = $n['tanggal_kembali'];
            $terimadari = $n['pelanggan'];
            $jumlahterima = $n['jumlah_bayar_sewa'];
            $jumtot = $jumtot+$jumlahterima;
        echo "<tr><td>$nomor</td><td>".tglindo($tgl)."</td><td>Transaksi terima dari $terimadari</td><td style='text-align:right;'>Rp. ".number_format($jumlahterima,0,",",".")."</td></tr>";
            
        }
        echo "<tr><td colspan=3>Total Pendapatan</td><td style='text-align:right;'>Rp. ".number_format($jumtot,0,",",".")."</td></tr>";
        echo "</table>";
    }
    ?>
    
</div><!--/panel content-->
