<?php
require_once 'koneksi.php';


if (isset($_POST['submit'])) {
    $idpel = $_POST['id_pelanggan'];
    $idmobil = $_POST['id_mobil'];
    $tgl = $_POST['tanggal'];
    $lama = $_POST['lama'];
    $trf = $_POST['tarif'];
    if (empty($idpel)) {
        echo "<script language='javascript'>alert ('Field id pelanggan kosong'); document.location.href='?page=sewa'</script>";
    } else if (empty($idmobil)) {
        echo "<script language='javascript'>alert ('Field id mobil kosong'); document.location.href='?page=sewa'</script>";
    } else if (empty($tgl)) {
        echo "<script language='javascript'>alert ('Field tgl kosong'); document.location.href='?page=sewa'</script>";
    } else if (empty($lama)) {
        echo "<script language='javascript'>alert ('Field lama sewa kosong'); document.location.href='?page=sewa'</script>";
    } else if (empty($trf)) {
        echo "<script language='javascript'>alert ('Field tarif kosong'); document.location.href='?page=sewa'</script>";
    } else {
        $sx = "UPDATE `km3_rental_mobil`.`mobil` SET `keterangan` = 'Tidak Ada' WHERE `mobil`.`id_mobil` = '$idmobil';";
        $qx = mysql_query($sx);

        $sql = "INSERT INTO sewa(id_sewa, id_pelanggan, id_mobil, tanggal_sewa, lama, tarif_harian) VALUES ('','$idpel','$idmobil','$tgl','$lama',$trf);";
        $query = mysql_query($sql);
        if ($query) {
            echo"<script language='javascript'>alert ('input data berhasil'); </script>
	<script language='javascript'>
	document.location.href='?page=daftarsewa'</script>";
        } else {
            echo "<script language='javascript'>alert ('input data gagal'); </script><script language='javascript'>
	document.location.href='?page=daftarsewa'</script>";
        }
    }
}
?>

<div class="modal" id="cekmobil">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                <h4 class="modal-title">Daftar Kendaraan</h4>
            </div>
            <div class="modal-body">
                <iframe src="list.php" scroll="yes" width="100%"></iframe>
            </div>
            <div class="modal-footer">
                <a href="#" data-dismiss="modal" class="btn">Close</a>
                <a href="?page=tambahmobil" class="btn btn-primary">Tambah Data Mobil</a>
                <a href="?page=tampilmobil" class="btn btn-primary">Edit Data Mobil</a>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dalog -->
</div><!-- /.modal -->

<div class="panel-heading">
    <div class="panel-title">
        <i class="glyphicon glyphicon-wrench pull-right"></i>
        <h4>Tambah Data Sewa Mobil</h4>
        <?php
$sql = "SELECT count(*) as jml FROM mobil WHERE keterangan = 'Ada'";
$hasil = mysql_query($sql);
if (!$hasil)
    print("Query tak dapat diproses lho");
else {
    $baris = mysql_fetch_row($hasil);

    $data_ada = TRUE;
    if (empty($baris)) {
        print("Tak ada yang memenuhi!");
        $data_ada = FALSE;
    }

    while ($baris) {
        $dt = $baris[0];
        // Sajikan ke pilihan
        echo "Kendaraan yang siap ada :<span class = \"badge pull-right\">$dt unit</span>";

        // Baca data berikutnya        
        $baris = mysql_fetch_row($hasil);
    }
}
?>
    </div>
</div>


<div class="panel-body">
    <div class="btn-group btn-group-justified">

        <a title="Add Widget" data-toggle="modal" href="#cekmobil" class="btn btn-primary col-sm-3">
            <i class="glyphicon glyphicon-plus"></i><br>
            Cek Ketersediaan Mobil
        </a>
    </div>

    <form class="form form-vertical" method="post" action="?page=sewa">

        <div class="control-group">
            <label>Id Pelanggan</label>
            <div class="controls">
                <select class="form-control" name='id_pelanggan' id='id_pelanggan'>
                    <option value=''>Pilih Pelanggan</option>	
                    <?php
                    $sq2 = "select * from pelanggan";
                    $q = mysql_query($sq2);
                    while ($rs = mysql_fetch_array($q)) {
                        echo "<option value='$rs[id_pelanggan]'>$rs[nama_pelanggan]</option>";
                    }
                    ?>

                </select>
            </div>
            <label>Id Mobil</label>
            <?php
            $sq2 = "select * from mobil where keterangan='Ada'";
            $q = mysql_query($sq2);
            ?>
            <div class="controls">
                <select class="form-control" name='id_mobil' id='id_mobil'><option value=''>Pilih id Mobil</option>	
                    <?php
                    while ($rs = mysql_fetch_array($q)) {
                        echo "<option value='$rs[id_mobil]'>$rs[no_polisi]</option>";
                    }
                    ?>
                </select>

            </div>
            <label>Tanggal Sewa</label>
            <div class="controls">
                <input type="text" class="form-control" name='tanggal' id='tanggal' value='<?php echo date('Y-m-d') ?>'>
            </div>
            <label>Lama</label>
            <div class="controls">
                <input type="text" class="form-control" name='lama' id='lama'>
            </div>
            <label>Tarif Harian</label>
            <div class="controls">
                <input type="text" class="form-control" name='tarif' id='tarif' value=''>
            </div>
        </div> 
        <div class="control-group">
            <label></label>
            <div class="controls">
                <button type="submit" class="btn btn-primary" value ='simpan' name='submit' id='submit'>
                    Simpan
                </button>
            </div>
        </div>   

    </form>


</div><!--/panel content-->