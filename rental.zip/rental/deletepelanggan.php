<?php
require_once 'koneksi.php';
 
$id_pelanggan = $_GET['id_pelanggan'];
$sql = "DELETE FROM pelanggan WHERE id_pelanggan='$id_pelanggan'";
$result = mysql_query($sql);
 
if ($result){

echo "Sukses menghapus data <br />
  <a href=\"http://localhost/rental/index.php?page=pelanggan&id_pelanggan=1\">Lihat Data</a>";
} else {
echo "Terjadi kesalahan";
}
?>
