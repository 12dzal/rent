
<?php
require_once 'koneksi.php';
$sqx = "select count(*) as no from mobil";
$qx = mysql_query($sqx);
while ($n = mysql_fetch_array($qx)) {
    $no = $n['no'];
}
$no_urut = $no + 1;

if (isset($_POST['submit'])) {
    $nopol = $_POST['nopol'];
    $jenis = $_POST['jenis'];
    $tarif = $_POST['tarif'];
    $ket = $_POST['ket'];
    // cek validasi data.
    if (empty($nopol)) {
        echo "<script language='javascript'>alert ('Field no polisi kosong'); document.location.href='?page=tambahmobil'</script>";
    } else if (empty($jenis)) {
        echo "<script language='javascript'>alert ('Field jenis/type kosong'); document.location.href='?page=tambahmobil'</script>";
    } else if (empty($tarif)) {
        echo "<script language='javascript'>alert ('Field tarif kosong'); document.location.href='?page=tambahmobil'</script>";
    } else if (empty($ket)) {
        echo "<script language='javascript'>alert ('Field status kosong'); document.location.href='?page=tambahmobil'</script>";
    } else {
        $sql = "INSERT INTO mobil(id_mobil, no_polisi, jenis, tarif, keterangan) VALUES ('$no_urut','$nopol','$jenis','$tarif','$ket');";
        $query = mysql_query($sql);
        if ($query) {
            echo"<script language='javascript'>alert ('input data berhasil'); </script>
	<script language='javascript'>
	document.location.href='?page=tampilmobil'</script>";
        } else {
            echo "<script language='javascript'>alert ('input data gagal'); </script>";
        }
    }
}
?>

<div class="panel-heading">
    <div class="panel-title">
        <i class="glyphicon glyphicon-wrench pull-right"></i>
        <h4>Tambah Data Mobil</h4>
    </div>
</div>
<div class="panel-body">
    <div class="btn-group btn-group-justified">
        <a href="?page=tampilmobil" class="btn btn-primary col-sm-3">
            <i class="glyphicon glyphicon-plus"></i><br>
            Daftar Mobil
        </a>
    </div>

    <form class="form form-vertical" method="post" action="?page=tambahmobil">

        <div class="control-group">
            <label>Nomor Polisi</label>
            <div class="controls">
                <input type="text" class="form-control" name='nopol' id='nopol'>
            </div>
            <label>Jenis/merk/type Mobil</label>
            <div class="controls">
                <input type="text" class="form-control" placeholder="Masukkan jenis/merk/type kendaraan" name='jenis' id='jenis'>
            </div>
            <label>Tarif harian</label>
            <div class="controls">
                <input type="text" class="form-control" placeholder="Masukkan tarif sewa harian" name='tarif' id='tarif'>
            </div>
            <label>Status Mobil</label>
            <div class="controls">
                <select class="form-control" name='ket' id='ket'><option value=''>pilih</option>	
                    <option value='Ada'>Ada</option>
                    <option value='Tidak ada'>Tidak ada</option></select>
            </div>
        </div> 
        <div class="control-group">
            <label></label>
            <div class="controls">
                <button type="submit" class="btn btn-primary" value ='simpan' name='submit' id='submit'>
                    Simpan
                </button>
            </div>
        </div>   

    </form>


</div><!--/panel content-->
