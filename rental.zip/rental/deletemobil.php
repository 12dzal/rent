<?php
require_once 'koneksi.php';
 
$id_mobil = $_GET['id_mobil'];
$sql = "DELETE FROM mobil WHERE id_mobil='$id_mobil'";
$result = mysql_query($sql);
 
 
if ($result){

echo "Sukses menghapus data <br />
  <a href=\"http://localhost/rental/index.php?page=tampilmobil\">Lihat Data</a>";
} else {
echo "Terjadi kesalahan";
} 
?>