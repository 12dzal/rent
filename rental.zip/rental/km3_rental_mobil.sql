-- phpMyAdmin SQL Dump
-- version 4.2.2deb2.precise~ppa.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 08, 2014 at 11:35 AM
-- Server version: 5.5.37-0ubuntu0.12.04.1
-- PHP Version: 5.3.10-1ubuntu3.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `km3_rental_mobil`
--

-- --------------------------------------------------------

--
-- Table structure for table `kembali`
--

CREATE TABLE IF NOT EXISTS `kembali` (
`id_kembali` int(10) unsigned NOT NULL,
  `id_sewa` int(11) NOT NULL,
  `tanggal_sewa` date NOT NULL,
  `tanggal_kembali` date NOT NULL,
  `lama_sewa` int(11) NOT NULL,
  `tarif_harian` double NOT NULL,
  `jumlah_bayar_sewa` double NOT NULL,
  `pelanggan` varchar(50) NOT NULL,
  `keterangan` varchar(100) NOT NULL,
  `created` date NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `kembali`
--

INSERT INTO `kembali` (`id_kembali`, `id_sewa`, `tanggal_sewa`, `tanggal_kembali`, `lama_sewa`, `tarif_harian`, `jumlah_bayar_sewa`, `pelanggan`, `keterangan`, `created`) VALUES
(1, 2, '2014-06-05', '2014-06-07', 2, 250000, 500000, 'Bejo', 'Lunas', '2014-06-07'),
(2, 7, '2014-06-06', '2014-06-07', 1, 250000, 250000, 'Udin', 'Lunas', '2014-06-07'),
(3, 6, '2014-06-06', '2014-06-07', 1, 250000, 250000, 'bejoxcccd', 'Lunas', '2014-06-07'),
(4, 9, '2014-06-06', '2014-06-07', 1, 150000, 150000, 'bejoxcccd', 'Lunas', '2014-06-07'),
(5, 8, '2014-06-06', '2014-06-07', 1, 400000, 400000, 'bejoxcccd', 'Lunas', '2014-06-07'),
(6, 12, '2014-06-07', '2014-06-08', 1, 1500000, 1500000, 'Nadia', 'Lunas', '2014-06-07');

-- --------------------------------------------------------

--
-- Table structure for table `mobil`
--

CREATE TABLE IF NOT EXISTS `mobil` (
`id_mobil` int(11) NOT NULL,
  `no_polisi` varchar(8) NOT NULL,
  `jenis` varchar(20) NOT NULL,
  `tarif` double NOT NULL,
  `keterangan` enum('Ada','Tidak Ada') NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `mobil`
--

INSERT INTO `mobil` (`id_mobil`, `no_polisi`, `jenis`, `tarif`, `keterangan`) VALUES
(1, 'AB1234DD', 'BMW', 250000, 'Ada'),
(2, 'AB2231SA', 'Xenia', 250000, 'Ada'),
(3, 'AB235ST', 'Avanza', 250000, 'Ada'),
(4, 'AB199XW', 'Porsche', 400000, 'Ada'),
(5, 'AB1212SS', 'Kijang', 150000, 'Ada'),
(6, 'AB99DC', 'Pajero Sport', 1500000, 'Ada');

-- --------------------------------------------------------

--
-- Table structure for table `pelanggan`
--

CREATE TABLE IF NOT EXISTS `pelanggan` (
`id_pelanggan` int(10) unsigned NOT NULL,
  `nama_pelanggan` varchar(50) NOT NULL,
  `alamat` varchar(100) NOT NULL,
  `identitas` varchar(10) NOT NULL,
  `no_telp` varchar(13) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `pelanggan`
--

INSERT INTO `pelanggan` (`id_pelanggan`, `nama_pelanggan`, `alamat`, `identitas`, `no_telp`) VALUES
(1, 'bejoxcccd', 'Solo', 'KTP', '0812345465'),
(2, 'trim bilcdfdf', 'Klaten', 'sim', '08534534535'),
(3, 'Nadia', 'Yogyakarta', 'KTP', '093484545'),
(4, 'Nadia', 'Solo', 'SIM', '0812345465'),
(5, 'Budi', 'Klaten', 'KTP', '1234323'),
(6, 'bejo kutul', 'Solo', 'ktp', '0812345465'),
(7, 'Budi Anduk', 'Klaten Utara', 'KTP', '1234323'),
(8, 'Trimbil XdSr', 'Klaten', 'sim', '08534534535'),
(9, 'trimbil fdfd', 'Klaten', 'sim', '08534534535'),
(10, 'sdfsd', 'sdfsdf', 'KTP', '34234'),
(11, 'Oman', 'Yogya', 'SIM', '0812345465'),
(12, 'Oman', 'Yogya', 'SIM', '08123419999');

-- --------------------------------------------------------

--
-- Table structure for table `sewa`
--

CREATE TABLE IF NOT EXISTS `sewa` (
`id_sewa` int(11) unsigned NOT NULL,
  `id_pelanggan` int(11) NOT NULL,
  `id_mobil` int(11) NOT NULL,
  `tanggal_sewa` date NOT NULL,
  `lama` int(11) NOT NULL,
  `tarif_harian` double NOT NULL,
  `status` enum('Sewa','Kembali') NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `sewa`
--

INSERT INTO `sewa` (`id_sewa`, `id_pelanggan`, `id_mobil`, `tanggal_sewa`, `lama`, `tarif_harian`, `status`) VALUES
(1, 1, 1, '2014-06-05', 3, 150000, 'Sewa'),
(2, 1, 1, '2014-06-05', 3, 250000, 'Sewa'),
(3, 2, 1, '2014-06-05', 5, 400000, 'Sewa'),
(4, 2, 1, '2014-06-05', 4, 250000, 'Sewa'),
(5, 1, 1, '2014-06-06', 0, 250000, 'Sewa'),
(6, 1, 2, '2014-06-06', 3, 250000, 'Sewa'),
(7, 1, 3, '2014-06-06', 1, 250000, 'Sewa'),
(8, 1, 4, '2014-06-06', 2, 400000, 'Sewa'),
(9, 1, 5, '2014-06-06', 4, 150000, 'Sewa'),
(10, 4, 5, '2014-06-06', 2, 150000, 'Sewa'),
(11, 3, 2, '2014-06-06', 2, 250000, 'Sewa'),
(12, 4, 6, '2014-06-07', 2, 1500000, 'Sewa');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `kembali`
--
ALTER TABLE `kembali`
 ADD PRIMARY KEY (`id_kembali`);

--
-- Indexes for table `mobil`
--
ALTER TABLE `mobil`
 ADD PRIMARY KEY (`id_mobil`);

--
-- Indexes for table `pelanggan`
--
ALTER TABLE `pelanggan`
 ADD PRIMARY KEY (`id_pelanggan`);

--
-- Indexes for table `sewa`
--
ALTER TABLE `sewa`
 ADD PRIMARY KEY (`id_sewa`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `kembali`
--
ALTER TABLE `kembali`
MODIFY `id_kembali` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `mobil`
--
ALTER TABLE `mobil`
MODIFY `id_mobil` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `pelanggan`
--
ALTER TABLE `pelanggan`
MODIFY `id_pelanggan` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `sewa`
--
ALTER TABLE `sewa`
MODIFY `id_sewa` int(11) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=13;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
