<?php
$action = $_GET['page'];
include 'fungsi.php';
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta http-equiv="content-type" content="text/html; charset=UTF-8">
        <meta charset="utf-8">
        <title>Bastian Rental Mobil</title>
        <meta name="generator" content="Bootply" />
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="css/jquery.ui.all.css">
		<script src="js/jquery-1.10.2.js"></script>
		<script src="js/jquery.ui.core.js"></script>
		<script src="js/jquery.ui.widget.js"></script>
		<script src="js/jquery.ui.datepicker.js"></script>
		<link rel="stylesheet" href="css/demos.css">
        
        <link href="css/styles.css" rel="stylesheet">
    </head>
    <body>
        <!-- Header -->
        <div id="top-nav" class="navbar navbar-inverse navbar-static-top">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="index.php">Bastian Rental Mobil</a>
                </div>
                <div class="navbar-collapse collapse">
                    <ul class="nav navbar-nav navbar-right">

                        <li class="dropdown">
                            <a class="dropdown-toggle" role="button" data-toggle="dropdown" href="#"><i class="glyphicon glyphicon-user"></i> Admin <span class="caret"></span></a>
                            <ul id="g-account-menu" class="dropdown-menu" role="menu">
                                <li><a href="#">My Profile</a></li>
                            </ul>
                        </li>
                        <li><a title="Add Widget" data-toggle="modal" href="#addWidgetModal"><span class="glyphicon glyphicon-plus-sign"></span> Tentang Aplikasi</a></li>
                    </ul>
                </div>
            </div><!-- /container -->
        </div>
        <!-- /Header -->

        <!-- Main -->
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <!-- Left column -->
                    <a href="#"><strong><i class="glyphicon glyphicon-wrench"></i> Menu Utama</strong></a>  
                    <hr>
                    <ul class="nav nav-pills nav-stacked">
                        <li class="nav-header"> <a href="#" data-toggle="collapse" data-target="#userMenu">
                                <h5>File <i class="glyphicon glyphicon-chevron-down"></i></h5>
                            </a>
                            <ul class="nav nav-pills nav-stacked collapse" id="userMenu">
                                <li><a href="?page=pelanggan"><i class="glyphicon glyphicon-user"></i> Pelanggan</a></li>
                                <li><a href="?page=tampilmobil"><i class="glyphicon-exclamation-sign"></i> Mobil</a></li>
                            </ul>
                        </li>
                        <li class="nav-header"> <a href="#" data-toggle="collapse" data-target="#userMenu2">
                                <h5>Transaksi <i class="glyphicon glyphicon-chevron-down"></i></h5>
                            </a>
                            <ul class="nav nav-pills nav-stacked collapse " id="userMenu2">
                                <li><a href="?page=sewa"><i class="glyphicon glyphicon-flag"></i> Sewa</a></li>
                                <li><a href="?page=kembali"><i class="glyphicon glyphicon-user"></i> Kembali</a></li>
                                <li><a href="?page=daftarsewa"><i class="glyphicon glyphicon-flag"></i>Daftar Transaksi Sewa</a></li>
                            </ul>
                        </li>
                        <li class="nav-header"> <a href="#" data-toggle="collapse" data-target="#menu2">
                                <h5>Laporan <i class="glyphicon glyphicon-chevron-right"></i></h5>
                            </a>

                            <ul class="nav nav-pills nav-stacked collapse" id="menu2">
                                <li><a href="?page=rekappendapatan">Rekap Pendapatan</a>
                                </li>
                                
                        </li>
                    </ul>
                    </li>
                    
                    </ul>
                    <hr>
                </div>
                <div class="col-md-9">

                    <div >
                        <div class="col-md-12">
                            <div class="panel panel-default">
                                
                                

                                <?php
                                menubutton();
                                
                                if (empty($action)) {
                                    include('home.php');
                                } else if (($action) == 'cari') {

                                    include('home.php');
                                } else if (($action) == 'pelanggan') {

                                    include('pelanggan.php');
                                } else if (($action) == 'tambahpelanggan') {

                                    include('tambahpelanggan.php');
                                } else if (($action) == 'editpelanggan') {

                                    include('editpelanggan.php');
                                } else if (($action) == 'tampilmobil') {

                                    include('tampilmobil.php');
                                } else if (($action) == 'tambahmobil') {

                                    include('tambahmobil.php');
                                } else if (($action) == 'editmobil') {

                                    include('editmobil.php');
                                } else if (($action) == 'sewa') {

                                    include('pinjam.php');
                                } else if (($action) == 'daftarsewa') {

                                    include('tampilsewa.php');
                                } else if (($action) == 'detailsewa') {

                                    include('detailsewa.php');
                                }else if (($action) == 'kembali') {

                                    include('kembali.php');
                                }else if (($action) == 'getinvoiece') {

                                    include('kembali.php');
                                }else if (($action) == 'kembalisewa') {

                                    include('kembalisewa.php');
                                }else if (($action) == 'rekappendapatan') {

                                    include('rekappendapatan.php');
                                }
                                ?>

                            </div>

                        </div>
                    </div>
                </div><
            </div>
        </div>
        

        <footer class="text-center ">Bastian Rental Mobil
			<br> Jl.Suka Birus No.105 </br>
            <br>&copy; 2015</footer>

        <div class="modal" id="addWidgetModal">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                        <h4 class="modal-title">Tentang Program</h4>
                    </div>
                    <div class="modal-body">
                        <p>APlikasi Rental Mobil</p>
						<p>Bastian Rental Mobil </p>
						<p>Jl.Suka Birus No.105</p>
                    </div>
                    <div class="modal-footer">
                        <a href="#" data-dismiss="modal" class="btn">keluar</a>
                        <a href="#" class="btn btn-primary">Simpan</a>
                    </div>
                </div>
            </div>
        </div>

   
        <script src="js/bootstrap.min.js"></script>
        <script src="js/scripts.js"></script>
    </body>
</html>
