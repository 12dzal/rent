<?php
$host = 'localhost';
$user = 'root';
$pass = '';
$dbname = 'km3_rental_mobil';
$connect = mysql_connect($host, $user, $pass);
$dbselect = mysql_select_db($dbname);

if(!$connect){
    echo "Koneksi gagal . .";
}
else{
    if(!$dbselect){
        echo "Database tidak ditemukan . .";
    }
}
?>