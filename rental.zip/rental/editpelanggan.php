<?php
require_once 'koneksi.php';

$id_pel = $_GET['id'];
if (isset($_POST['submit'])) {
    $nama = $_POST['nama'];
    $alamat = $_POST['alamat'];
    $identitas = $_POST['identitas'];
    $telp = $_POST['telp'];
    $id = $_POST['idpel'];

    $sql = "UPDATE pelanggan SET nama_pelanggan='$nama',alamat='$alamat',identitas='$identitas',no_telp='$telp' WHERE id_pelanggan=$id";
    $query = mysql_query($sql);
    if ($query) {
        echo"<script language='javascript'>alert ('Edit data berhasil'); </script>
	<script language='javascript'>
	document.location.href='index.php?page=pelanggan'</script>";
    } else {
        echo "<script language='javascript'>alert ('Edit data gagal'); </script><script language='javascript'>
	document.location.href='index.php?page=pelanggan'</script>";
    }
}
?>



<div class="panel-heading">
    <div class="panel-title">
        <i class="glyphicon glyphicon-wrench pull-right"></i>
        <h4>Edit Data Pelanggan</h4>
    </div>
</div>
<div class="panel-body">

    <?php
    $sql = "select * from pelanggan where id_pelanggan=$id_pel";
    $query = mysql_query($sql);
    while ($d = mysql_fetch_array($query)) {
        ?>
    </table>

    <form method="post" action="?page=editpelanggan">
        <div class="control-group">
            <table>
                <tr>
                    <td><label>Id Pelanggan</label></td><td width="20">:</td>
                    <td><div class="controls"><input type="hidden" class="form-control"  name='idpel' id='idpel' value='<?php echo $d['id_pelanggan']; ?>'><?php echo $d['id_pelanggan']; ?></div></td>
                </tr>
                <tr>
                    <td>Nama Pelanggan</td><td>:</td><td><div class="controls"><input type="text" class="form-control" name='nama' id='nama' value='<?php echo $d['nama_pelanggan']; ?>'></div></td>
                </tr>
                <tr>
                    <td>Alamat</td><td>:</td><td><div class="controls"><input type="text" class="form-control" name='alamat' id='alamat' rows=5 cols=30 value='<?php echo $d['alamat']; ?>'></div></td>

                </tr>
                <tr>
                    <td>Identitas</td><td>:</td><td><input type="text" class="form-control" name='identitas' id='identitas' value='<?php echo $d['identitas']; ?>'></td>

                </tr>
                <tr>
                    <td>no Telpon</td><td>:</td><td><input type="text" class="form-control" name='telp' id='telp' value='<?php echo $d['no_telp']; ?>'></td>
                </tr>
            </table>
        </div>
        <div class="control-group">
            <label></label>
            <div class="controls">
                <button type="submit" class="btn btn-primary" value ='simpan' name='submit' id='submit'>
                    Simpan
                </button>
            </div>
        </div>

    </form>

<?php } ?>

</div><!--/panel content-->