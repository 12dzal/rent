
<div class="panel-heading">
    <div class="panel-title">
        <i class="glyphicon glyphicon-wrench pull-right"></i>
        <h4>Pengembalian Sewa</h4>
    </div>
</div>
<div class="panel-body">


    <form method="post" action="?page=getinvoiece">
        <br>
        <div class="control-group">
            <label>Masukkan Nomor Invoice</label>
            <table><tr>
                    <td width="100"><input type="text" class="form-control"  name='key' id='key' ></td><td width="20"></td>
                    <td><button type="submit" class="btn btn-primary" value ='Cari' name='caribtn' id='caribtn'>
                            Cari
                        </button></td>
                </tr>
            </table>



        </div> 


    </form>
    <hr>
    <?php
    require_once 'koneksi.php';
// proses pencarian data
    if (isset($_GET['page'])) {
        if ($_GET['page'] == 'getinvoiece') {


            $key = $_POST['key'];
            //$kriteria = $_POST['kriteria'];
            if (empty($key)) {
                echo "<script language='javascript'>alert ('Masukkan kata kunci ex.a '); document.location.href='index.php?page=kembali'</script>";
            } else {


                $tt = "select count(*) as jumlah from sewa where id_sewa = '$key'";
                $qxt = mysql_query($tt);
                while ($d = mysql_fetch_array($qxt)) {
                    $hasilcari = $d['jumlah'];
                    echo "<p>Ditemukan $d[jumlah]  data terkait Nomor Invoice : '" . $key . "'</p>";
                }
                if ($hasilcari == 0) {
                    echo "Data tidak ditemukan";
                } else {
                    $sqx = "select count(*) as no from kembali";
                    $qx = mysql_query($sqx);
                    while ($n = mysql_fetch_array($qx)) {
                        $no = $n['no'];
                    }
                    $no_urut = $no + 1;

                    $sql = "SELECT sewa.id_sewa,sewa.id_pelanggan,pelanggan.nama_pelanggan,sewa.id_mobil, mobil.jenis, mobil.no_polisi, sewa.tanggal_sewa, sewa.lama, sewa.tarif_harian, sewa.status FROM sewa,pelanggan,mobil where sewa.id_pelanggan = pelanggan.id_pelanggan and sewa.id_mobil = mobil.id_mobil and sewa.id_sewa='$key'";
                    $query = mysql_query($sql);
                    echo "<table width='100%' class=\"table table-striped\">
                    <tr>
                    <th>No Invoice</th><th>Nama</th><th>Jenis/type</th><th>No. Polisi</th><th>Tanggal Sewa</th><th>Lama</th><th>Status</th>
                    </tr>";


                    while ($d = mysql_fetch_array($query)) {
                        $trf = $d['tarif_harian'];
                        
                        $date1 = $d['tanggal_sewa'];
                        $date2 = date("Y-m-d");
                        $diff = abs(strtotime($date2) - strtotime($date1));
                        $years = floor($diff / (365 * 60 * 60 * 24));
                        $months = floor(($diff - $years * 365 * 60 * 60 * 24) / (30 * 60 * 60 * 24));
                        $days = floor(($diff - $years * 365 * 60 * 60 * 24 - $months * 30 * 60 * 60 * 24) / (60 * 60 * 24));
                        if($days==0){
                            $jumbayar = $trf * 1;
                        }else{
                        $jumbayar = $trf * $days;
                        }
                        echo "<tr>"
                        . "<td>$d[id_sewa]</td><td>$d[nama_pelanggan]</td>"
                        . "<td>$d[jenis]</td><td>$d[no_polisi]</td>"
                        . "<td>$d[tanggal_sewa]</td><td>$d[lama]</td>"
                        . "<td>$d[status]</td>"
                        . "</tr>";
                        echo "</table><hr>";
                        ?> 

                        <a title="Add Widget" data-toggle="modal" href="#kembalitrans" class="btn btn-primary btn-group btn-group-justified">
                            Form Pengembalian Mobil
                        </a>
                        <div class="modal" id="kembalitrans">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                        <h4 class="modal-title">Daftar Kendaraan</h4>
                                    </div>
                                    <div class="modal-body">
                                        <form method="post" action="?page=kembalisewa">
                                            <div class="control-group">
                                                <table>
                                                    
                                                    <tr>
                                                        <td width="150">Id Kembali</td><td width="20">:</td>
                                                        <td><input type="hidden" class="form-control" name='idkembali' id='idkembali' value='<?php echo $no_urut; ?>'><?php echo $no_urut; ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td width="150">Id Transaksi</td><td width="20">:</td>
                                                        <td><input type="hidden" class="form-control" name='idtrnas' id='idtrnas' value='<?php echo $d['id_sewa']; ?>'><?php echo $d['id_sewa']; ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td width="150">Id Mobil</td><td width="20">:</td>
                                                        <td><input type="hidden" class="form-control" name='idmobil' id='idmobil' value='<?php echo $d['id_mobil']; ?>'><?php echo $d['id_mobil']; ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Tanggal Sewa</td><td>:</td>
                                                        <td><input type="hidden" class="form-control" name='tglsewa' id='tglsewa' value='<?php echo $d['tanggal_sewa']; ?>'><?php echo $d['tanggal_sewa']; ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Tanggal Kembali</td><td>:</td>
                                                        <td><input type="hidden" class="form-control" name='tglkembali' id='tglkembali' value='<?php echo date('Y-m-d') ?>'><?php echo date('Y-m-d') ?></td>

                                                    </tr>
                                                    <tr>
                                                        <td>Lama</td><td>:</td>
                                                        <td><input type="hidden" class="form-control" name='lamasewa' id='lamasewa' value='<?php echo $days; ?>'><?php echo $days; ?></td>

                                                    </tr>
                                                    <tr>
                                                        <td>Tarif Harian</td><td>:</td>
                                                        <td><input type="hidden" class="form-control" name='tarifharian' id='tarifharian' value='<?php echo $d['tarif_harian']; ?>'><?php echo $d['tarif_harian']; ?></td>

                                                    </tr>
                                                     <tr>
                                                        <td>Jumlah</td><td>:</td>
                                                        <td><input type="hidden" class="form-control" name='jumbayar' id='jumbayar' value='<?php echo $jumbayar; ?>'><?php echo $jumbayar; ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Pelanggan</td><td>:</td>
                                                        <td><input type="hidden" class="form-control" name='customer' id='customer' value='<?php echo $d['nama_pelanggan']; ?>'><?php echo $d['nama_pelanggan']; ?> </td>
                                                    </tr>
                                                    <tr>
                                                        <td>Keterangan</td><td>:</td><td><select class="form-control" name='ket' id='ket'>
                                                                <option value=''>Pilih</option>	
                                                                <option value='Lunas'>Lunas</option>
                                                                <option value='Belum Lunas'>Belum Lunas</option>


                                                            </select></td>
                                                    </tr>


                                                </table>
                                            </div>
                                            <div class="control-group">
                                                <label></label>
                                                <div class="controls">
                                                    <button type="submit" class="btn btn-primary" value ='simpan' name='submit' id='submit'>
                                                        Simpan
                                                    </button>
                                                </div>
                                            </div>   
                                        </form>            

                                    </div>
                                    <div class="modal-footer">
                                        <a href="#" data-dismiss="modal" class="btn">Close</a>
                                        <a href="?page=tambahmobil" class="btn btn-primary">Tambah Data Mobil</a>
                                        <a href="?page=tampilmobil" class="btn btn-primary">Edit Data Mobil</a>
                                    </div>
                                    <?php
                                }
                            }
                        }
                    }
                }
                ?>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dalog -->
    </div><!-- /.modal -->


</div><!--/panel content-->

<?php
?>