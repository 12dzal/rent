ini aplikasi rental mobil, harus membuat database yang berisikan mobil-mobil yang akan direntalkan
menggunakan phpmyadmin untuk membuatnya
untuk aplikasi nya, bisa berjalan jika database sudah di tambahkan.