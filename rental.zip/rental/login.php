<!DOCTYPE html>
<html>
 <head>
  <title>log in</title>
  <meta charset="utf-8">
 </head>
  <body background="Accord.jpg">
  <div id="header">
 <h1>log in</h1>
 </div>
 <form action="homeadmin.php" method="post">
<fieldset>
<legend>log in</legend>
<p>login admin</p>
 <ol>
User name:<br>
<input type="text" name="username">
<br>
User password:<br>
<input type="password" name="psw">
 <input type="submit" value="submit">
</fieldset>
 </form>
 <style>
 body {
 background-color: #FFFFFF;
 margin: 0 15%;
 font-family: comic sans ms;
 color: #FF4500
 }
h1 {
 text-align: center;
 font-family: serif;
 font-weight: normal;
 text-transform: uppercase;
  border-bottom: 1px solid #57b1dc;
 margin-top: 30px;
}
h2 {
 text-color: #FFA500;
 font-size: 1em;
}
</style>
</body>
</html>