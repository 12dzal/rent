<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

function tglindo($date) { // fungsi atau method untuk mengubah tanggal ke format indonesia
    // variabel BulanIndo merupakan variabel array yang menyimpan nama-nama bulan
    $BulanIndo = array("Januari", "Februari", "Maret",
        "April", "Mei", "Juni",
        "Juli", "Agustus", "September",
        "Oktober", "November", "Desember");

    $tahun = substr($date, 0, 4); // memisahkan format tahun menggunakan substring
    $bulan = substr($date, 5, 2); // memisahkan format bulan menggunakan substring
    $tgl = substr($date, 8, 2); // memisahkan format tanggal menggunakan substring

    $result = $tgl . " " . $BulanIndo[(int) $bulan - 1] . " " . $tahun;
    return($result);
}

function menubutton() {
    echo" 
    <div class = \"btn-group btn-group-justified\">
    <a href = \"?page=pelanggan\" class = \"btn btn-primary col-sm-3\">
    <i class = \"glyphicon glyphicon-plus\"></i><br>
    Pelanggan
    </a>
    <a href = \"?page=tampilmobil\" class = \"btn btn-primary col-sm-3\">
    <i class = \"glyphicon glyphicon-cloud\"></i><br>
    Mobil
    </a>
    <a href = \"?page=sewa\" class = \"btn btn-primary col-sm-3\">
    <i class = \"glyphicon glyphicon-cog\"></i><br>
    Sewa
    </a>
    <a href = \"?page=daftarsewa\" class = \"btn btn-primary col-sm-3\">
    <i class = \"glyphicon glyphicon-wrench\"></i><br>
    Daftar Sewa
    </a>
    <a href = \"?page=kembali\" class = \"btn btn-primary col-sm-3\">
    <i class = \"glyphicon glyphicon-wrench\"></i><br>
    Kembali
    </a>
    <a href = \"?page=kembalisewa\" class = \"btn btn-primary col-sm-3\">
    <i class = \"glyphicon glyphicon-wrench\"></i><br>
    Daftar Kembali
    </a>
    <a href = \"?page=rekappendapatan\" class = \"btn btn-primary col-sm-3\">
    <i class = \"glyphicon glyphicon-wrench\"></i><br>
    Pendapatan
    </a>
    </div>
    ";
}

?>