<div class="panel-heading">
    <div class="panel-title">
        <i class="glyphicon glyphicon-wrench pull-right"></i>
        <h4>Daftar Pengembalian Kendaraan</h4>
    </div>
</div>
<div class="panel-body">
    <?php
    require_once 'koneksi.php';

    if (isset($_POST['submit'])) {
        $idtrnas = $_POST['idtrnas'];
        $idkembali = $_POST['idkembali'];
        $tglsewa = $_POST['tglsewa'];
        $tglkembali = $_POST['tglkembali'];
        $lamasewa = $_POST['lamasewa'];
        $tarifharian = $_POST['tarifharian'];
        $jumbayar = $_POST['jumbayar'];
        $customer = $_POST['customer'];
        $ket = $_POST['ket'];
        $idmobil = $_POST['idmobil'];



        if (empty($idtrnas)) {
            echo "<script language='javascript'>alert ('Field id transaksi kosong'); document.location.href='?page=kembali'</script>";
        } else if (empty($idkembali)) {
            echo "<script language='javascript'>alert ('Field id kembali kosong'); document.location.href='?page=kembali'</script>";
        } else if (empty($tglsewa)) {
            echo "<script language='javascript'>alert ('Field tgl sewa kosong'); document.location.href='?page=kembali'</script>";
        } else if (empty($tglkembali)) {
            echo "<script language='javascript'>alert ('Field tgl kembali kosong'); document.location.href='?page=kembali'</script>";
        } else if (empty($lamasewa)) {
            echo "<script language='javascript'>alert ('Field lama sewa kosong'); document.location.href='?page=kembali'</script>";
        } else if (empty($tarifharian)) {
            echo "<script language='javascript'>alert ('Field tarif kosong'); document.location.href='?page=kembali'</script>";
        } else if (empty($jumbayar)) {
            echo "<script language='javascript'>alert ('Field jumlah bayar kosong'); document.location.href='?page=kembali'</script>";
        } else if (empty($customer)) {
            echo "<script language='javascript'>alert ('Field pelanggan kosong'); document.location.href='?page=kembali'</script>";
        } else if (empty($ket)) {
            echo "<script language='javascript'>alert ('Field keterangan kosong'); document.location.href='?page=kembali'</script>";
        } else {
            
            $sx = "UPDATE `km3_rental_mobil`.`mobil` SET `keterangan` = 'Ada' WHERE `mobil`.`id_mobil` = '$idmobil';";
        $qx = mysql_query($sx);

            $sql = "INSERT INTO kembali "
                    . "(id_kembali, id_sewa, tanggal_sewa, tanggal_kembali, lama_sewa, "
                    . "tarif_harian, jumlah_bayar_sewa, pelanggan, keterangan, created) "
                    . "VALUES ('$idkembali', '$idtrnas', '$tglsewa', '$tglkembali', '$lamasewa', '$tarifharian', '$jumbayar', '$customer', '$ket', now());";





            $query = mysql_query($sql);
            if ($query) {
                echo "<div class=\"alert alert-info\"><button type=\"button\" class=\"close\" data-dismiss=\"alert\">×</button>
    Simpan Data Pengembalian Mobil Berhasil'.";

                echo "<table class=\"table table-striped\"><tr><td width='150'>Kode Kembali</td><td width='20'>:</td><td>$idkembali</td></tr>"
                . "<tr><td>Kode Invoice</td><td>:</td><td>$idtrnas</td></tr>"
                . "<tr><td>Tanggal Sewa</td><td>:</td><td>$tglsewa</td></tr>"
                . "<tr><td>Tanggal Pengembalian</td><td>:</td><td>$tglkembali</td></tr>"
                . "<tr><td>Lama Sewa</td><td>:</td><td>$lamasewa</td></tr>"
                . "<tr><td>Tarif Sewa</td><td>:</td><td>$tarifharian</td></tr>"
                . "<tr><td>Bayar Sewa</td><td>:</td><td>$jumbayar</td></tr>"
                . "<tr><td>Pelanggan</td><td>:</td><td>$customer</td></tr>"
                . "<tr><td>Keterangan</td><td>:</td><td>$ket</td></tr>"
                . "</table></div>";
            } else {
                echo "<div class=\"alert alert-info\"><button type=\"button\" class=\"close\" data-dismiss=\"alert\">×</button>
    Simpan Data Pengembalian Mobil Gagal'.</div>";
            }
        }
    }
    ?>


    <table width='100%' class="table table-striped">

        <tr>
            <th>No</th><th>id pengembalian</th><th>id sewa</th><th>tgl sewa</th><th>tgl kbl</th><th>lama</th><th>tarif</th><th>bayar</th><th>cust</th><th>ket</th>
        </tr>
        <?php
        $sql = "select * from kembali";
        $query = mysql_query($sql);
        $no = 0;
        while ($d = mysql_fetch_array($query)) {
            $no++;
            echo "<tr><td>$no</td><td>$d[id_kembali]</td><td>$d[id_sewa]</td>"
                    . "<td>$d[tanggal_sewa]</td><td>$d[tanggal_kembali]</td><td>$d[lama_sewa]</td>"
                    . "<td>$d[tarif_harian]</td><td>$d[jumlah_bayar_sewa]</td><td>$d[pelanggan]</td>"
                    . "<td>$d[keterangan]</td></tr>";
        }
        ?>
    </table>
</div>

