
<div class="panel-heading"><h4>Daftar Mobil</h4></div>
<div class="panel-body">
    
    <?php
    require_once 'koneksi.php';
    ?>
    <div class="btn-group btn-group-justified">
        <a href="?page=tambahmobil" class="btn btn-primary col-sm-3">
            <i class="glyphicon glyphicon-plus"></i><br>
            Tambah Data Mobil
        </a>
    </div>
    <table width='100%' class="table table-striped">

        <tr>
            <th>No</th><th>No Polisi</th><th>Jenis</th><th>Tarif</th><th>Keterangan</th><th>Aksi</th>
        </tr>
        <?php
        $sql = "select * from mobil";
        $query = mysql_query($sql);
        $no = 0;
        while ($d = mysql_fetch_array($query)) {
            $no++;
            echo "<tr><td>$no</td><td>$d[no_polisi]</td><td>$d[jenis]</td><td>$d[tarif]</td><td>$d[keterangan]</td>
	<td><a href='?page=editmobil&id=$d[id_mobil]'>Edit</a> - 
	<a href=\"deletemobil.php?id_mobil=".$d['id_mobil']."\">Delete</a></td>";
        }
        
        ?>
    </table>
</div>