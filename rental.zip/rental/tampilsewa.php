
<div class="panel-heading"><h4>Daftar Transaksi Sewa</h4></div>
<div class="panel-body">
    <?php
    require_once 'koneksi.php';
    ?>
    <div class="btn-group btn-group-justified">
        <a href="?page=sewa" class="btn btn-primary col-sm-3">
            <i class="glyphicon glyphicon-plus"></i><br>
            Transaksi Baru
        </a>
    </div>
    <table width='100%' class="table table-striped">

        <tr>
            <th>No</th><th>inv</th><th>Nama</th><th>Jenis</th><th>No Polisi</th><th>Tgl Sewa</th><th>Lama</th><th>Status</th>
        </tr>
        <?php
        //membuat paginasi tampil 5 data per halaman
        $batas = 10; // menentukan batas / limit data yang akan ditampilkan
        //$halaman = $_GET['halaman']; //untuk menyimpan data halaman
        if (empty($halaman)) { //jika get halaman bernilai kosong
            $posisi = 0; // menentukan posisi awal record
            $halaman = 1; // menentukan posisi halaman 1
        } else {
            $posisi = ($halaman - 1) * $batas;
        }
        $sql = "SELECT sewa.id_sewa,sewa.id_pelanggan,pelanggan.nama_pelanggan,sewa.id_mobil, "
                . "mobil.jenis, mobil.no_polisi, sewa.tanggal_sewa, sewa.lama, sewa.tarif_harian, sewa.status "
                . "FROM sewa,pelanggan,mobil where sewa.id_pelanggan = pelanggan.id_pelanggan and "
                . "sewa.id_mobil = mobil.id_mobil order by sewa.tanggal_sewa desc limit $posisi,$batas"; 
        $query = mysql_query($sql);
        $no = 1;
        while ($d = mysql_fetch_array($query)) {

            echo "<tr><td>$no</td><td>$d[id_sewa]</td><td>$d[nama_pelanggan]</td><td>$d[jenis]</td><td>$d[no_polisi]</td><td>$d[tanggal_sewa]</td><td>$d[lama]</td><td>$d[status]</td>
	<td><a class=\"btn btn-primary\" href='?page=detailsewa&id=$d[id_sewa]'>Detail</a> - <a class=\"btn btn-primary\" href='editsewa.php?id=$d[id_sewa]'>Edit</a></td></tr>";

            $no++;
        }
        ?>

    </table>
    <hr>
    <?php
    
    $sql_paging = mysql_query("select id_sewa  from sewa");
    $jmldata = mysql_num_rows($sql_paging);
    $jumlah_halaman = ceil($jmldata / $batas);

    echo "Halaman :";
    for ($i = 1; $i <= $jumlah_halaman; $i++)
        if ($i != $halaman) {
            echo "<a href=index.php?page=daftarsewa&halaman=$i>$i</a>|";
        } else {
            echo "<b>$i</b>|";
        }
    mysql_close();
    ?>
    <br>
    Jumlah data :<?php echo $jmldata; ?>
</div>