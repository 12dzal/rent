
<div class="panel-heading"><h4>Data Detail Transaksi</h4></div>
<div class="panel-body">
    <?php
    require_once 'koneksi.php';
    require_once 'fungsi.php';

    $getid = $_GET['id'];

    require_once 'koneksi.php';

    $sql = "SELECT sewa.id_sewa,sewa.id_pelanggan,pelanggan.nama_pelanggan,sewa.id_mobil, mobil.jenis, mobil.no_polisi, sewa.tanggal_sewa, sewa.lama, sewa.tarif_harian, sewa.status FROM sewa,pelanggan,mobil where sewa.id_pelanggan = pelanggan.id_pelanggan and sewa.id_mobil = mobil.id_mobil and sewa.id_sewa='$getid'";
    $query = mysql_query($sql);

    while ($d = mysql_fetch_array($query)) {
        $tarif = $d['tarif_harian'];

        echo" <p>Nota Transaksi Nomor : $d[id_sewa]</p>
<table class=\"table table-striped\">
    <tr>
        <td width=200>Id Pelanggan</td><td width=20>:</td><td width=350>$d[id_pelanggan]</td>
    </tr>
    <tr>
        <td>Nama Pelanggan</td><td>:</td><td>$d[nama_pelanggan]</td>
    </tr>
    <tr>
        <td>Id Mobil</td><td>:</td><td>$d[id_mobil]</td>
    </tr>
    <tr>
        <td>Jenis Mobil yang disewa</td><td>:</td><td>$d[jenis]</td>
    </tr>
    <tr>
        <td>Nomor Polisi</td><td>:</td><td>$d[no_polisi]</td>
    </tr>
    <tr>
        <td>Tanggal Sewa</td><td>:</td><td>".tglindo($d['tanggal_sewa'])."</td>
    </tr>
    <tr>
        <td>Lama Sewa</td><td>:</td><td>$d[lama]</td>
    </tr>
    <tr>
        <td>Tarif Harian</td><td>:</td><td>Rp. " . number_format($tarif, 0, ",", ".") . "</td>
    </tr>
    
</table>";
    }
    ?>
    <input type="button" class="btn btn-primary" value="Cetak" onclick="myFunction();">
    
</div>
<script>
    function myFunction() {
        var myWindow = window.open("cetaknota.php?nota=<?php echo $getid; ?>", "", "width=500, height=800");
    }
</script>