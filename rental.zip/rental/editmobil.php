<?php
require_once 'koneksi.php';

$id_mbl = $_GET['id'];
if (isset($_POST['submit'])) {
    $nopol = $_POST['nopol'];
    $jenis = $_POST['jenis'];
    $ket = $_POST['ket'];
    $tarif = $_POST['tarif'];
    $id = $_POST['idmobil'];

    $sql = "UPDATE mobil SET no_polisi='$nopol',jenis='$jenis',tarif='$tarif',keterangan='$ket' WHERE id_mobil=$id";
    $query = mysql_query($sql);
    if ($query) {
        echo"<script language='javascript'>alert ('Edit data berhasil'); </script>
	<script language='javascript'>
	document.location.href='?page=tampilmobil'</script>";
    } else {
        echo "<script language='javascript'>alert ('Edit data gagal'); </script><script language='javascript'>
	document.location.href='?page=tampilmobil'</script>";
    }
}
?>

<div class="panel-heading">
    <div class="panel-title">
        <i class="glyphicon glyphicon-wrench pull-right"></i>
        <h4>Tambah Data Mobil</h4>
    </div>
</div>
<div class="panel-body">
    <?php
    $sql = "select * from mobil where id_mobil=$id_mbl";
    $query = mysql_query($sql);
    while ($d = mysql_fetch_array($query)) {
        ?>

        <form method="post" action="?page=editmobil">
            <div class="control-group">
                <table>
                    <tr>
                        <td width="150">Id Mobil</td><td width="20">:</td><td><input type="hidden" class="form-control" name='idmobil' id='idmobil' value='<?php echo $d['id_mobil']; ?>'><?php echo $d['id_mobil']; ?></td>
                    </tr>
                    <tr>
                        <td>Nomor Polisi</td><td>:</td><td><input type="text" class="form-control" name='nopol' id='nopol' value='<?php echo $d['no_polisi']; ?>'></td>
                    </tr>
                    <tr>
                        <td>Jenis</td><td>:</td><td><input type="text" class="form-control" name='jenis' id='jenis' rows=5 cols=30 value='<?php echo $d['jenis']; ?>'></td>

                    </tr>
                    <tr>
                        <td>Tarif</td><td>:</td><td><input type="text" class="form-control" name='tarif' id='tarif' value='<?php echo $d['tarif']; ?>'></td>

                    </tr>
                    <tr>
                        <td>Keterangan</td><td>:</td><td><select class="form-control" name='ket' id='ket'>
                                <option value='value='<?php echo $d['keterangan']; ?>><?php echo $d['keterangan']; ?></option>	
                                <option value='Ada'>Ada</option>
                                <option value='Tidak ada'>Tidak ada</option>


                            </select></td>
                    </tr>


                </table>
            </div>
            <div class="control-group">
                <label></label>
                <div class="controls"
				>
                    <button type="submit" class="btn btn-primary" value ='simpan' name='submit' id='submit'>
                        Simpan
                    </button>
                </div>
            </div>   
        </form>

    <?php } ?>	

</div><!--/panel content-->