
<?php
require_once 'koneksi.php';
$sqx = "select count(*) as no from pelanggan";
$qx = mysql_query($sqx);
while ($n = mysql_fetch_array($qx)) {
    $no = $n['no'];
}
$no_urut = $no + 1;

if (isset($_POST['submit'])) {
    $nama = $_POST['nama'];
    $alamat = $_POST['alamat'];
    $identitas = $_POST['identitas'];
    $telp = $_POST['telp'];
// cek validasi data.
    if (empty($nama)) {
        echo "<script language='javascript'>alert ('Field nomor urut kosong'); document.location.href='?page=tambahpelanggan'</script>";
    } else if (empty($alamat)) {
        echo "<script language='javascript'>alert ('Field alamat kosong'); document.location.href='?page=tambahpelanggan'</script>";
    } else if (empty($identitas)) {
        echo "<script language='javascript'>alert ('Field identitas kosong'); document.location.href='?page=tambahpelanggan'</script>";
    } else if (empty($telp)) {
        echo "<script language='javascript'>alert ('Field no telpon kosong'); document.location.href='?page=tambahpelanggan'</script>";
    } else {

        $sql = "INSERT INTO pelanggan(id_pelanggan, nama_pelanggan,alamat, identitas, no_telp) VALUES ('$no_urut','$nama','$alamat','$identitas','$telp');";
        $query = mysql_query($sql);
        if ($query) {
            echo"<script language='javascript'>alert ('input data berhasil'); </script>
	<script language='javascript'>
	document.location.href='?page=pelanggan'</script>";
        } else {
            echo "<script language='javascript'>alert ('input data gagal'); </script>";
        }
    }
}
?>
<div class="panel-heading">
    <div class="panel-title">
        <i class="glyphicon glyphicon-wrench pull-right"></i>
        <h4>Tambah Data Pelanggan</h4>
    </div>
</div>
<div class="panel-body">
    <div class="btn-group btn-group-justified">
        <a href="?page=pelanggan" class="btn btn-primary col-sm-3">
            <i class="glyphicon glyphicon-plus"></i><br>
            Daftar Pelanggan
        </a>
    </div>

    <form class="form form-vertical" method="post" action="?page=tambahpelanggan">

        <div class="control-group">
            <label>Id Pelanggan</label>
            <div class="controls">
                <input type="text" class="form-control" disabled name='id_pel' id='id_pel' value='<?php echo $no_urut; ?>'>
            </div>
            <label>Nama Pelanggan</label>
            <div class="controls">
                <input type="text" class="form-control" placeholder="Masukkan nama" name='nama' id='nama'>
            </div>
            <label>Alamat</label>
            <div class="controls">
                <textarea class="form-control" name='alamat' id='alamat'></textarea>
            </div>
            <label>Identitas</label>
            <div class="controls">
                <input type="text" class="form-control" placeholder="Masukkan jenis identitas" name='identitas' id="identitas">
            </div>
            <label>Nomor Telpon</label>
            <div class="controls">
                <input type="text" class="form-control" placeholder="Masukkan no. telp (ex. 0123456789)" name='telp' id="telp">
            </div>
        </div> 
        <div class="control-group">
            <label></label>
            <div class="controls">
                <button type="submit" class="btn btn-primary" value ='simpan' name='submit' id='submit'>
                    Simpan
                </button>
            </div>
        </div>   

    </form>


</div><!--/panel content-->
