<!DOCTYPE html>
<html lang="en">
    <head>
        <meta http-equiv="content-type" content="text/html; charset=UTF-8">
        <meta charset="utf-8">
        <title>Aplikasi Rental Mobil</title>
        <meta name="generator" content="Bootply" />
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <!--[if lt IE 9]>
                <script src="//html5shim.googlecode.com/svn/trunk/html5.js"></script>
        <![endif]-->
        <link href="css/styles.css" rel="stylesheet">
    </head>
    <body>
        <table width='100%' class="table table-striped">
            <tr><th colspan=5>Daftar Mobil</th>
            <tr>
                <th>No</th><th>No Polisi</th><th>Jenis</th><th>Tarif</th><th>Keterangan</th>
            </tr>
            <?php
            require_once 'koneksi.php';
            $sql = "select * from mobil";
            $query = mysql_query($sql);
            $no = 0;
            while ($d = mysql_fetch_array($query)) {
                $no++;
                echo "<tr><td>$no</td><td>$d[no_polisi]</td><td>$d[jenis]</td><td>$d[tarif]</td><td>$d[keterangan]</td>
	</tr>";
            }
            ?>
        </table>
    </body>